# ROSE Android 0.4.0 build package

This package updates the Android app version metadata to 0.4.0 and configures GitHub Actions to build and upload a debug APK.

Important: this is a build/version update of the supplied 0.3.0 source. It does not yet implement the requested 3D orb with 20+ colors, smarter auto-reply, or faster notification processing. Those require code changes and device testing.

To build: upload the contents of this folder to a GitHub repository, then open the Actions tab and run `ROSE AI 0.4.0 Build` (or push to `main`/`master`).
