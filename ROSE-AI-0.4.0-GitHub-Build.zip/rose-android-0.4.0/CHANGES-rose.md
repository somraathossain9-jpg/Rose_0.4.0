# Rose 0.3.0

- Long-term memory: notes kept up to 2000 (was 200), the latest 40 are given to Rose at the start of every
  conversation, she saves lasting facts by herself, and never deletes anything unless told to forget it.
- Messages from people (Settings -> Messages): "Ask me" reads each message out and asks whether to reply
  (the spoken yes is still checked by the phone); "Auto (busy)" answers people by itself as the owner's
  assistant, keeps chatting (Gemini writes each reply), max 8 replies an hour per chat, never groups, codes or links.
  The tool auto_reply_set lets you switch it by voice ("tumi reply dite thako").
- Faster message alerts: the notification listener rebinds itself when Android drops it, and the app asks once
  to be excluded from battery optimisation.
- Bangla is the default reply language (Bangladeshi Bangla); the Bangla voice reads messages aloud.
- Persona: Rose is a girl character and a caring friend; owner name is Somraat Islam Srabon.

# Changes since the Jarvis -> Rose rename

- Voice picker (female voices first, default Kore), reply language incl. Bangla/Banglish, model name field (Settings).
- Bangla (bn-IN) added to speech recognition, so what you say appears in Bangla script.
- Talk over reacts sooner (TalkOver quick settings in VoiceSession).
- "Send and call without asking" (default off): only plain Send/Call in messaging apps and the dialer
  (ControlRules.autoAllowed). Payments, delete, OTP, passwords and banking apps still need you.
- Friendly mode: jokes, playful arguments, calls the owner Boss / Samrat Boss / Shrabon / Sir.
- 20 moods (assistant/Mood.kt) via the silent set_mood tool; the orb changes colour and has a 3D look (ui/Orb.kt).
- Instructions v9: careful listening and checking each tool result.
